import { test, expect } from '@playwright/test';

test('Use Case 3 - API Test', async ({ request }) => {

  // SEND API REQUEST
  const response = await request.get('https://jsonplaceholder.typicode.com/posts/1');

  // VERIFY STATUS
  expect(response.status()).toBe(200);

  // GET RESPONSE DATA
  const data = await response.json();

  // VALIDATE DATA
  expect(data.id).toBe(1);
  expect(data.userId).toBe(1);

});