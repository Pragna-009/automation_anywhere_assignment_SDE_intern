import { test } from '@playwright/test';

test('Use Case 1 - Stable Submission Version', async ({ page }) => {

  // LOGIN
  await page.goto('https://community.cloud.automationanywhere.digital/#/login');

  await page.getByRole('textbox', { name: 'Username' }).fill('pragnacp04@gmail.com');
  await page.getByRole('textbox', { name: 'Password' }).fill('Jazzle_@_123');

  await page.getByRole('button', { name: 'Log in' }).click();

  // NAVIGATE
  await page.getByRole('link', { name: 'Automation', exact: true }).click();

  // CREATE TASK BOT
  await page.getByRole('heading', { name: 'Automation Create Manage' }).getByLabel('Create').click();
  await page.getByRole('button', { name: /Task Bot/ }).click();

  const botName = 'Bot_' + Date.now();

  await page.getByRole('textbox', { name: 'Name' }).fill(botName);
  await page.getByRole('button', { name: 'Create & edit' }).click();

  // WAIT FOR EDITOR
  await page.waitForTimeout(5000);

  // =========================
  // ADD MESSAGE BOX
  // =========================
  await page.getByPlaceholder('Search actions').fill('message');
  await page.getByRole('button', { name: 'Message box', exact: true }).click();

  await page.waitForTimeout(2000);

  // =========================
  // DEMONSTRATE INTERACTION
  // =========================

  // Click canvas
  await page.locator('.taskbot-canvas-flow__background').click();

  // Type something (interaction proof)
  await page.keyboard.type('Hello from Automation');

  await page.waitForTimeout(1000);

  // =========================
  // SAVE
  // =========================
  await page.getByRole('button', { name: 'Save' }).click();

  await page.waitForTimeout(4000);

});