import { test } from '@playwright/test';

test('Use Case 2 - FINAL SUBMISSION', async ({ page }) => {

  // LOGIN
  await page.goto('https://community.cloud.automationanywhere.digital/#/login');

  await page.getByRole('textbox', { name: 'Username' }).fill('pragnacp04@gmail.com');
  await page.getByRole('textbox', { name: 'Password' }).fill('Jazzle_@_123');

  await page.getByRole('button', { name: 'Log in' }).click();

  // NAVIGATE
  await page.getByRole('link', { name: 'Automation', exact: true }).click();

  // CREATE FORM
  await page.getByRole('heading', { name: 'Automation Create Manage' }).getByLabel('Create').click();
  await page.getByRole('button', { name: /Form/ }).click();

  const formName = 'Form_' + Date.now();

  await page.getByRole('textbox', { name: 'Name' }).fill(formName);
  await page.getByRole('button', { name: 'Create & edit' }).click();

  // WAIT FOR BUILDER
  await page.waitForTimeout(5000);

  // HANDLE IFRAME
  const frame = page.frameLocator('iframe');

  // ADD ELEMENTS
  await frame.getByRole('button', { name: 'Text Box' }).click();
  await frame.getByRole('button', { name: 'Select File' }).click();

  // FILL TEXT FIELD
  await frame.locator('input[type="text"]').first().fill('Test User');

  // SAVE (inside iframe)
  await frame.getByRole('button', { name: /save/i }).click({ force: true });

});