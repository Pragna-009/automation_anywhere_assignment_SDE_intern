import { Page } from '@playwright/test';

export class LoginPage {
  page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async login(email: string, password: string) {

    await this.page.goto('https://community.cloud.automationanywhere.digital/#/login');

    await this.page.getByRole('textbox', { name: 'Username' }).fill(email);

    await this.page.getByRole('textbox', { name: 'Password' }).fill(password);

    await Promise.all([
      this.page.waitForURL(/home|automation|bots/),
      this.page.getByRole('button', { name: 'Log in' }).click()
    ]);
  }
}